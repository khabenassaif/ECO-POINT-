import { db, storage } from "hatchable";
import { requireEcoAdmin } from "lib/admin-access.js";

export const access="public";
export const methods=["GET"];

export default async function(req,res){
  if(!await requireEcoAdmin(req,res)) return;
  const id=String(req.query?.id||"");
  if(id){
    const row=(await db.query("SELECT r.*,p.full_name,p.email,c.name category,c.points category_points FROM waste_reports r JOIN eco_profiles p ON p.user_id=r.user_id JOIN waste_categories c ON c.id=r.category_id WHERE r.id=$1",[id])).rows[0];
    if(!row) return res.status(404).json({error:"Laporan tidak ditemukan."});
    const [checks,reviews,history]=await Promise.all([
      db.query("SELECT check_type,passed,details,created_at FROM automated_checks WHERE report_id=$1 ORDER BY created_at",[id]),
      db.query("SELECT admin_id,decision,reason,created_at FROM admin_reviews WHERE report_id=$1 ORDER BY created_at",[id]),
      db.query("SELECT r.id,r.status,r.submitted_at,c.name category FROM waste_reports r JOIN waste_categories c ON c.id=r.category_id WHERE r.user_id=$1 AND r.id<>$2 ORDER BY r.submitted_at DESC LIMIT 5",[row.user_id,id])
    ]);
    return res.json({report:{...row,photo_url:await storage.url(row.photo_key,{ttl:300})},automated_checks:checks.rows,reviews:reviews.rows,user_history:history.rows});
  }
  const status=String(req.query?.status||"");
  const params=[]; let where="";
  if(status){params.push(status);where="WHERE r.status=$1";}
  const rows=(await db.query(
    `SELECT r.id,r.status,r.latitude,r.longitude,r.submitted_at,p.full_name,p.email,c.name category FROM waste_reports r JOIN eco_profiles p ON p.user_id=r.user_id JOIN waste_categories c ON c.id=r.category_id ${where} ORDER BY CASE WHEN r.status='pending_admin' THEN 0 ELSE 1 END,r.submitted_at DESC LIMIT 200`,
    params
  )).rows;
  res.json({reports:rows});
}