import { db } from "hatchable";
import { requireEcoAdmin } from "lib/admin-access.js";

export const access="public";
export const methods=["POST"];

export default async function(req,res){
  if(!await requireEcoAdmin(req,res)) return;
  const reportId=String(req.body?.report_id||"");
  const decision=String(req.body?.decision||"");
  const reason=String(req.body?.reason||"").trim().slice(0,1200);
  if(!["approved","rejected"].includes(decision)) return res.status(400).json({error:"Keputusan tidak valid."});
  if(decision==="rejected"&&!reason) return res.status(400).json({error:"Alasan penolakan wajib diisi."});
  const report=(await db.query("SELECT r.*,c.points,c.name category_name FROM waste_reports r JOIN waste_categories c ON c.id=r.category_id WHERE r.id=$1",[reportId])).rows[0];
  if(!report) return res.status(404).json({error:"Laporan tidak ditemukan."});
  if(report.status==="approved"||report.status==="rejected") return res.status(409).json({error:"Laporan sudah diputuskan."});
  const points=Number(report.points);
  if(decision==="approved"&&(!Number.isInteger(points)||points<5||points>10))return res.status(409).json({error:"Nilai poin kategori harus 5–10. Periksa pengaturan kategori."});
  const adminId=String(req.ecoAdminUsername);
  const statements=[
    {sql:"UPDATE waste_reports SET status=$2,reviewed_at=NOW(),reviewed_by=$3,rejection_reason=$4,awarded_points=$5 WHERE id=$1 AND status IN ('submitted','automated_review','pending_admin')",params:[reportId,decision,adminId,decision==="rejected"?reason:null,decision==="approved"?points:0]},
    {sql:"SELECT CASE WHEN (SELECT reviewed_by=$2 AND status=$3 AND reviewed_at IS NOT NULL FROM waste_reports WHERE id=$1) THEN 1 ELSE 1/0 END",params:[reportId,adminId,decision]},
    {sql:"INSERT INTO admin_reviews (report_id,admin_id,decision,reason) VALUES ($1,$2,$3,$4)",params:[reportId,adminId,decision,reason||null]}
  ];
  if(decision==="approved"){
    statements.push(
      {sql:"INSERT INTO point_transactions (user_id,type,points,report_id,reason) VALUES ($1,'report_reward',$2,$3,$4)",params:[report.user_id,points,reportId,"Poin laporan disetujui: "+report.category_name]},
      {sql:"INSERT INTO notifications (user_id,title,body,type) VALUES ($1,$2,$3,$4)",params:[report.user_id,"Laporan disetujui",`Laporan disetujui admin. Kamu memperoleh ${points} poin.`,"report_approved"]}
    );
  }else{
    statements.push({sql:"INSERT INTO notifications (user_id,title,body,type) VALUES ($1,$2,$3,$4)",params:[report.user_id,"Laporan ditolak","Laporan ditolak admin: "+reason,"report_rejected"]});
  }
  try{
    await db.transaction(statements);
    res.json({ok:true,status:decision});
  }catch(e){
    res.status(409).json({error:"Keputusan tidak dapat disimpan. Laporan mungkin telah diproses oleh admin lain."});
  }
}