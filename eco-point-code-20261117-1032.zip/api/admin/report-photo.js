import { db, storage } from "hatchable";
import { requireEcoAdmin } from "lib/admin-access.js";

export const access="public";
export const methods=["GET"];

export default async function(req,res){
  if(!await requireEcoAdmin(req,res)) return;
  const id=String(req.query?.id||"");
  const row=(await db.query("SELECT photo_key FROM waste_reports WHERE id=$1",[id])).rows[0];
  if(!row) return res.status(404).send("Not found");
  res.setHeader("Cache-Control","private, max-age=60");
  res.redirect(302,await storage.url(row.photo_key,{ttl:120}));
}