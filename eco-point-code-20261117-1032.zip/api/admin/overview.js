import { db } from "hatchable";
import { requireEcoAdmin } from "lib/admin-access.js";

export const access="public";
export const methods=["GET"];

export default async function(req,res){
  if(!await requireEcoAdmin(req,res)) return;
  const [stats,statuses,categories,trend,redemptions,recent]=await Promise.all([
    db.query("SELECT (SELECT COUNT(*) FROM eco_profiles)::int students,(SELECT COUNT(*) FROM waste_reports)::int reports,(SELECT COUNT(*) FROM waste_reports WHERE status='approved')::int approved,(SELECT COUNT(*) FROM waste_reports WHERE status='rejected')::int rejected,(SELECT COUNT(*) FROM waste_reports WHERE status='pending_admin')::int pending,(SELECT COUNT(DISTINCT user_id) FROM waste_reports WHERE submitted_at>NOW()-INTERVAL '30 days')::int active_users,(SELECT COALESCE(SUM(points),0) FROM point_transactions WHERE type='report_reward')::int points_distributed,(SELECT COUNT(*) FROM redemptions)::int redemptions,(SELECT COUNT(*) FROM redemptions WHERE status='ready')::int pending_pickups"),
    db.query("SELECT status,COUNT(*)::int count FROM waste_reports GROUP BY status ORDER BY status"),
    db.query("SELECT c.name,COUNT(r.id)::int count FROM waste_categories c LEFT JOIN waste_reports r ON r.category_id=c.id GROUP BY c.id,c.name ORDER BY count DESC,c.name"),
    db.query("SELECT DATE(submitted_at) AS report_date,COUNT(*)::int AS count FROM waste_reports WHERE submitted_at>NOW()-INTERVAL '30 days' GROUP BY DATE(submitted_at) ORDER BY report_date"),
    db.query("SELECT status,COUNT(*)::int count FROM redemptions GROUP BY status ORDER BY status"),
    db.query("SELECT r.id,r.status,r.submitted_at,p.full_name,c.name category FROM waste_reports r JOIN eco_profiles p ON p.user_id=r.user_id JOIN waste_categories c ON c.id=r.category_id ORDER BY r.submitted_at DESC LIMIT 6")
  ]);
  res.json({stats:stats.rows[0],report_statuses:statuses.rows,category_distribution:categories.rows,report_trend:trend.rows,redemption_statuses:redemptions.rows,recent_reports:recent.rows});
}